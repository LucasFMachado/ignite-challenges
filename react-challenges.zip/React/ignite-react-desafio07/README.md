Desafio:
https://efficient-sloth-d85.notion.site/Desafio-01-Otimizando-a-aplica-o-2942004b422d455891756300d88d0b9a