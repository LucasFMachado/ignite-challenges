Desafio:
https://www.notion.so/Desafio-01-Database-Queries-8d97dae581d5446e97555c43d301ee45