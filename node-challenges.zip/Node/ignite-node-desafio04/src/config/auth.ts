export default {
  jwt: {
    secret: "senhasupersecreta123",
    expiresIn: '1d'
  }
}
