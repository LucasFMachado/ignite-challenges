export interface IGetStatementOperationDTO {
  user_id: string;
  statement_id: string;
}
