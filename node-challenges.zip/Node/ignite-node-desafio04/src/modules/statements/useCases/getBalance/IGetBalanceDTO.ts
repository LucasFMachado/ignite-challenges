export interface IGetBalanceDTO {
  user_id: string;
  with_statement?: boolean;
}
