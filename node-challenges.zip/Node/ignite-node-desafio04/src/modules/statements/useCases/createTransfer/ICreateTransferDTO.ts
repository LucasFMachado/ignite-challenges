
export interface ICreateTransferDTO {
  amount: number;
  description: string;
  senderUserID: string;
  receiverUserID: string;
}
